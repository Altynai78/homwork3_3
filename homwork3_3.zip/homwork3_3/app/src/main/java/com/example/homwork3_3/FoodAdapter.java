package com.example.homwork3_3;

import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class FoodAdapter extends RecyclerView.Adapter {
    public FoodAdapter(ArrayList<String> foodList) {
    }
}
